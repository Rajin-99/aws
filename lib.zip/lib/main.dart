import 'package:flutter/material.dart';
import 'dart:async';

void main() {
  runApp(const PictureFrameApp());
}

class PictureFrameApp extends StatelessWidget {
  const PictureFrameApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Digital Picture Frame',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue),
      ),
      home: const PictureFrameScreen(),
      debugShowCheckedModeBanner: false, // Removes the debug banner
    );
  }
}

class PictureFrameScreen extends StatefulWidget {
  const PictureFrameScreen({super.key});

  @override
  State<PictureFrameScreen> createState() => _PictureFrameScreenState();
}

class _PictureFrameScreenState extends State<PictureFrameScreen> {
  // S3 Bucket URLs
  final List<String> imageUrls = [
    'https://rjgallery.s3.us-east-1.amazonaws.com/Atlantic%20Salmon4.jpg',
    'https://rjgallery.s3.us-east-1.amazonaws.com/bison.jpg',
    'https://rjgallery.s3.us-east-1.amazonaws.com/cougar.jpg',
    'https://rjgallery.s3.us-east-1.amazonaws.com/northern.jpg',
  ];

  int _currentImageIndex = 0;
  late Timer _timer;
  bool _isPaused = false;

  @override
  void initState() {
    super.initState();
    _startImageRotation();
  }

  @override
  void dispose() {
    _timer.cancel();
    super.dispose();
  }

  void _startImageRotation() {
    _timer = Timer.periodic(const Duration(seconds: 10), (timer) {
      if (!_isPaused) {
        setState(() {
          _currentImageIndex = (_currentImageIndex + 1) % imageUrls.length;
        });
      }
    });
  }

  void _togglePauseResume() {
    setState(() {
      _isPaused = !_isPaused;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Digital Picture Frame'),
      ),
      body: Center(
        child: Container(
          decoration: BoxDecoration(
            border: Border.all(color: Colors.blueAccent, width: 10),
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(
                color: Colors.grey.withOpacity(0.5),
                spreadRadius: 5,
                blurRadius: 7,
                offset: const Offset(0, 3),
              ),
            ],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(20),
            child: Image.network(
              imageUrls[_currentImageIndex],
              fit: BoxFit.cover,
              height: 300,
              width: 300,
              loadingBuilder: (context, child, loadingProgress) {
                if (loadingProgress == null) {
                  return child;
                }
                return const Center(
                  child: CircularProgressIndicator(),
                );
              },
              errorBuilder: (context, error, stackTrace) {
                return const Center(
                  child: Text(
                    'Image not available',
                    style: TextStyle(color: Colors.red),
                  ),
                );
              },
            ),
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _togglePauseResume,
        tooltip: _isPaused ? 'Resume' : 'Pause',
        child: Icon(_isPaused ? Icons.play_arrow : Icons.pause),
      ),
    );
  }
}
